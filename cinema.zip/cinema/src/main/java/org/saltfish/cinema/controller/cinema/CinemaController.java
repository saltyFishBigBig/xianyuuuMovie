package org.saltfish.cinema.controller.cinema;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.CinemaBasicInfo;
import org.saltfish.cinema.service.cinema.CinemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api
@CrossOrigin
@RestController
@RequestMapping("/cinema")
public class CinemaController {

    @Autowired
    private CinemaService cinemaService;


    @PostMapping
    @ApiOperation("添加一个影院，不需要影院id")
    public ResponseVo<Object> addCinema (@RequestBody CinemaBasicInfo cinemaBasicInfo) {

        cinemaService.saveCinema(cinemaBasicInfo);

        return ResponseUtil.toSuccessResponseVo();
    }


    @PutMapping
    @ApiOperation("更新一个影院信息，需要影院id")
    public ResponseVo<Object> updateCinema (@RequestBody CinemaBasicInfo cinemaBasicInfo) {

        cinemaService.saveCinema(cinemaBasicInfo);

        return ResponseUtil.toSuccessResponseVo();
    }


    @DeleteMapping
    @ApiOperation("删除一个影院")
    public ResponseVo<Object> deleteCinema (@RequestParam Long cinemaId) {

        cinemaService.deleteCinema(cinemaId);

        return ResponseUtil.toSuccessResponseVo();
    }


    @GetMapping
    @ApiOperation("根据影院id查询影院")
    public ResponseVo<CinemaBasicInfo> findById (@RequestParam Long cinemaId) {

        return ResponseUtil.toSuccessResponseVo(cinemaService.getCinema(cinemaId));
    }

    @GetMapping("/area")
    @ApiOperation("根据地区查询影院")
    public ResponseVo<List<CinemaBasicInfo>> findByArea (@RequestParam String area) {

        return ResponseUtil.toSuccessResponseVo(cinemaService.findByArea(area));
    }


    @GetMapping("/all")
    @ApiOperation("获取全部影院信息")
    public ResponseVo<List<CinemaBasicInfo>> findAllCinemas() {
        return ResponseUtil.toSuccessResponseVo(cinemaService.findAllCinemas());
    }


    @GetMapping("/like/name")
    @ApiOperation("根据影院名称的模糊查询")
    public ResponseVo<List<CinemaBasicInfo>> findByNameLike(@RequestParam String name) {
        return ResponseUtil.toSuccessResponseVo(cinemaService.findByNameLick("%"+name+"%"));
    }


}
