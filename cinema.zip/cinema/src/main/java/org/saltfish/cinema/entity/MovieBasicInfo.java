package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.saltfish.cinema.commons.annotation.Comment;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table
@Entity
@Data
@ApiModel("电影视图")
public class MovieBasicInfo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long movieId;

    @ApiModelProperty("电影名称")
    private String movieName;

    @ApiModelProperty("电影类型")
    private String movieType;

    @ApiModelProperty("电影时长")
    private String movieTime;

    @ApiModelProperty("主演")
    private String actor;

    @ApiModelProperty("简介")
    private String info;

    @ApiModelProperty("电影上映时间（仅日期）")
    private String releaseTime;

    @Enumerated(EnumType.STRING)
    @ApiModelProperty("电影等级")
    private MovieLevelEnum level;

    @ApiModelProperty("评分")
    private Double score;

    @ApiModelProperty("封面图片存放路径")
    private String cover;
}
