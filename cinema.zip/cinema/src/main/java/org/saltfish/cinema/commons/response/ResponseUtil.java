package org.saltfish.cinema.commons.response;

public class ResponseUtil {

    /**
     * 自定义基本响应
     * @param responseStatus
     * @param msg
     * @param data
     * @param <T>
     * @return
     */
    public static <T> ResponseVo<T> toResponseVo(ResponseStatus responseStatus, String msg, T data) {
        ResponseVo<T> responseVo = new ResponseVo<>();

        responseVo.setResponseStatus(responseStatus);
        responseVo.setMsg(msg);
        responseVo.setData(data);

        return responseVo;
    }

    /**
     * 响应成功并返回数据
     * @param data
     * @param <T>
     * @return
     */
    public static <T> ResponseVo<T> toSuccessResponseVo(T data) {
        return toResponseVo(ResponseStatus.OK, "操作成功！", data);
    }

    /**
     * 响应成功且没有需要返回的数据
     * @param <T>
     * @return
     */
    public static <T> ResponseVo<T> toSuccessResponseVo() {
        return toResponseVo(ResponseStatus.NO_CONTENT, "操作成功！", null);
    }

    /**
     * 响应失败且无返回数据
     * @param responseStatus
     * @param msg
     * @param <T>
     * @return
     */
    public static <T> ResponseVo<T> toFailResponseVo(ResponseStatus responseStatus, String msg) {
        return toResponseVo(responseStatus, msg, null);
    }

}
