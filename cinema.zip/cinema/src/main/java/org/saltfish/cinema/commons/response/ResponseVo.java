package org.saltfish.cinema.commons.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ResponseVo<T> {

    @ApiModelProperty("请求的响应状态")
    private ResponseStatus responseStatus;

    @ApiModelProperty("提示信息")
    private String msg;

    @ApiModelProperty("数据展示，允许为null")
    private T data;
}
