package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.CinemaMovieInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface CinemaMovieRepository extends JpaRepository<CinemaMovieInfo, Long>, JpaSpecificationExecutor {

    CinemaMovieInfo findByCinemaMovieId(Long id);

    List<CinemaMovieInfo> findByMovieBasicInfo_MovieId(Long movieId);

    List<CinemaMovieInfo> findByCinemaBasicInfo_CinemaId(Long cinemaId);
}
