package org.saltfish.cinema.service.account;

import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.AccountInfo;


public interface AccountService {

    void saveAccount(AccountInfo accountInfo);

    void deleteAccount(Long accountId);

    AccountInfo findByUserId(Long userId);

    ResponseVo<Object> decreaseAccount(Long orderId);

    ResponseVo<Object> plusAccount(Long orderId);
}
