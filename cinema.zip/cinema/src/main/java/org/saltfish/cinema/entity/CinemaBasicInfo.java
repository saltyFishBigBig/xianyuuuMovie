package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Table
@Entity
@Data
@ApiModel("影院视图")
public class CinemaBasicInfo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cinemaId;

    @ApiModelProperty("影院名称")
    private String cinemaName;

    @ApiModelProperty("影院所在地区")
    private String area;

    @ApiModelProperty("影院详细地址")
    private String address;

    @ApiModelProperty("影院联系电话")
    private String phoneNumber;

    @ApiModelProperty("影院图片所在路径")
    private String photo;
}
