package org.saltfish.cinema.service.movie.impl;

import org.saltfish.cinema.dao.CinemaMovieRepository;
import org.saltfish.cinema.dao.MovieRepository;
import org.saltfish.cinema.entity.CinemaMovieInfo;
import org.saltfish.cinema.entity.MovieBasicInfo;
import org.saltfish.cinema.entity.MovieLevelEnum;
import org.saltfish.cinema.service.movie.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MovieServiceImpl implements MovieService {

    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private CinemaMovieRepository cinemaMovieRepository;

    @Override
    public void saveMovie(MovieBasicInfo movieBasicInfo) {
        movieRepository.save(movieBasicInfo);
    }

    @Override
    public void saveCinemaMovie(CinemaMovieInfo cinemaMovieInfo) {
        cinemaMovieRepository.save(cinemaMovieInfo);
    }

    @Override
    public void deleteMovie(Long movieId) {
        movieRepository.deleteById(movieId);
    }

    @Override
    public void deleteCinemaMovie(Long cinemaMovieId) {
        cinemaMovieRepository.deleteById(cinemaMovieId);
    }

    @Override
    public MovieBasicInfo findMovieById(Long movieId) {
        return movieRepository.findByMovieId(movieId);
    }

    @Override
    public List<MovieBasicInfo> getAllMovies() {
        return movieRepository.findAll();
    }

    @Override
    public List<MovieBasicInfo> findByMovieLevel(MovieLevelEnum movieLevel) {
        return movieRepository.findByLevel(movieLevel);
    }

    @Override
    public List<CinemaMovieInfo> findCinemaMoviesByMovieId(Long movieId) {
        return cinemaMovieRepository.findByMovieBasicInfo_MovieId(movieId);
    }

    @Override
    public CinemaMovieInfo findCinemaMovieById(Long cinemaMovieId) {
        return cinemaMovieRepository.findByCinemaMovieId(cinemaMovieId);
    }

    @Override
    public List<CinemaMovieInfo> findMoviesByCinema(Long cinemaId) {
        return cinemaMovieRepository.findByCinemaBasicInfo_CinemaId(cinemaId);
    }

    @Override
    public List<MovieBasicInfo> findByNameLick(String name) {
        return movieRepository.findByMovieNameLike(name);
    }
}
