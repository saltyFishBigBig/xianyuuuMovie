package org.saltfish.cinema.entity.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@ApiModel("订单视图")
public class OrderDto {

    @ApiModelProperty(value = "用户id")
    private Long userBasicInfoId;

    @ApiModelProperty(value = "影院中电影id")
    private Long cinemaMovieInfoId;

    @ApiModelProperty(value = "座次-第几行")
    private Integer row;

    @ApiModelProperty(value = "座次-第几列")
    private Integer line;

    @ApiModelProperty(value = "是否为情侣座")
    private Boolean loverSeat;
}
