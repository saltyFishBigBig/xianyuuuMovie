package org.saltfish.cinema.service.user;

import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.UserBasicInfo;

import javax.servlet.http.HttpSession;

public interface UserService {

    void addUserByPhoneNumber(UserBasicInfo userBasicInfo);

    void addUserByEmail(UserBasicInfo userBasicInfo);

    UserBasicInfo checkUser(UserBasicInfo userBasicInfo);

    ResponseVo<Object> deleteUser(Long userId, HttpSession httpSession);

    ResponseVo<Object> updateUser(UserBasicInfo userBasicInfo, HttpSession httpSession);

    UserBasicInfo getUserByUserId(Long userId);

    UserBasicInfo getUserByUserName(String userName);
}
