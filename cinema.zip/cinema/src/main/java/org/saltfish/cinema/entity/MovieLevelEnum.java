package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;

@ApiModel("电影状态视图")
public enum MovieLevelEnum {

    //
    READY("即将上映"),
    HOT("正在热映"),
    OTHER("其他影片");

    String comment;

    MovieLevelEnum(String comment) {
        this.comment = comment;
    }
}
