package org.saltfish.cinema.service.cinema;

import org.saltfish.cinema.entity.CinemaBasicInfo;

import java.util.List;

public interface CinemaService {

    /**
     * 增加或修改影院信息
     * @param cinemaBasicInfo
     */
    void saveCinema(CinemaBasicInfo cinemaBasicInfo);

    /**
     * 删除影院信息
     * @param cinemaId
     */
    void deleteCinema(Long cinemaId);

    /**
     * 根据地址筛选影院
     * @param area
     * @return
     */
    List<CinemaBasicInfo> findByArea(String area);

    /**
     * 根据id获取一个影院
     * @param cinemaId
     * @return
     */
    CinemaBasicInfo getCinema(Long cinemaId);

    /**
     * 获取全部影院
     * @return
     */
    List<CinemaBasicInfo> findAllCinemas();


    /**
     * 根据影院名称的模糊查询
     * @param name
     * @return
     */
    List<CinemaBasicInfo> findByNameLick(String name);

}
