package org.saltfish.cinema.service.order;

import org.saltfish.cinema.entity.OrderInfo;
import org.saltfish.cinema.entity.OrderStatusEnum;
import org.saltfish.cinema.entity.dto.OrderDto;

import java.util.List;

public interface OrderService {

    /**
     * 下订单
     * @param orderDto
     */
    List<OrderInfo> addOrder(OrderDto orderDto);

    /**
     * 退票
     * @param orderId
     */
    List<OrderInfo> undoOrder(Long orderId);

    /**
     * 查看某一用户的全部订单详情
     * @param userId
     * @return
     */
    List<OrderInfo> getAllOrders(Long userId);

    /**
     * 获取用户处于某种状态的全部订单
     * @param userId
     * @param orderStatus
     * @return
     */
    List<OrderInfo> getOrderOfStatus(Long userId, OrderStatusEnum orderStatus);

    OrderInfo getOrderByOrderId(Long orderId);

    /**
     * 获取一场电影的全部订单
     * @param cinemaMovieId
     * @return
     */
    List<OrderInfo> getOrdersOfCinemaMovie(Long cinemaMovieId);

}
