package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table
@ApiModel("账户余额视图")
public class AccountInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long accountId;

    Long userId;

    @Column(columnDefinition = "double default 0")
    @ApiModelProperty("账户余额")
    double account;
}
