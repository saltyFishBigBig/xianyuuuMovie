package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.OrderInfo;
import org.saltfish.cinema.entity.OrderStatusEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface OrderReposiroty extends JpaRepository<OrderInfo, Long>, JpaSpecificationExecutor {

    /**
     * 获取某一用户的全部订单
     * @param userId
     * @return
     */
    List<OrderInfo> findByUserBasicInfo_UserId(Long userId);


    /**
     * 获取某一用户处于某种状态的全部订单
     * @param userId
     * @param orderStatus
     * @return
     */
    List<OrderInfo> findByUserBasicInfo_UserIdAndOrderStatus(Long userId, OrderStatusEnum orderStatus);


    /**
     * 获取某一场电影的全部订单
     * @param cinemaMovieId
     * @return
     */
    List<OrderInfo> findByCinemaMovieInfo_CinemaMovieId(Long cinemaMovieId);

}
