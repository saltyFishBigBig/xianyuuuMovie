package org.saltfish.cinema.controller.user;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.UserBasicInfo;
import org.saltfish.cinema.commons.verify.VerifyCodeUtil;
import org.saltfish.cinema.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.OutputStream;

import static org.saltfish.cinema.commons.response.ExceptionMessages.*;
import static org.saltfish.cinema.commons.response.ResponseStatus.BAD_REQUEST;
import static org.saltfish.cinema.commons.response.ResponseStatus.UNAUTHORIZED;


@Api
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "/registerByEmail", method = RequestMethod.POST)
    @ApiOperation("通过邮箱注册")
    public ResponseVo<UserBasicInfo> registerByEmail(@RequestBody UserBasicInfo userBasicInfo) {
        userService.addUserByEmail(userBasicInfo);
        return ResponseUtil.toSuccessResponseVo(userBasicInfo);
    }

    @RequestMapping(value = "/registerByPhone", method = RequestMethod.POST)
    @ApiOperation("通过手机号注册")
    public ResponseVo<UserBasicInfo> registerByPhone(@RequestBody UserBasicInfo userBasicInfo) {
        userService.addUserByPhoneNumber(userBasicInfo);
        return ResponseUtil.toSuccessResponseVo(userBasicInfo);
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ApiOperation("登录")
    public ResponseVo<Long> login(@RequestBody UserBasicInfo userBasicInfo,@RequestParam(value = "code",defaultValue = "",required = false) String code, HttpServletRequest httpServletRequest) {
        HttpSession httpSession = httpServletRequest.getSession();
        String imageCode = (String) httpSession.getAttribute("imageCode");
        if (code == null) {
            return ResponseUtil.toFailResponseVo(BAD_REQUEST, VERIFYCODE_NULL);
        } else if (!imageCode.equals(code)) {
            return ResponseUtil.toFailResponseVo(UNAUTHORIZED, VERIFYCODE_FAIL);
        }
        UserBasicInfo getUser = userService.checkUser(userBasicInfo);
        if(getUser == null){
            return ResponseUtil.toFailResponseVo(BAD_REQUEST,USERNAME_NOT_EXIST);
        }
        httpServletRequest.getSession().setAttribute("userId", getUser.getUserId());
        return ResponseUtil.toSuccessResponseVo(getUser.getUserId());
    }

    @RequestMapping(value = "/unLogin",method = RequestMethod.POST)
    @ApiOperation("注销")
    public ResponseVo<Object>unLogin(HttpSession httpSession){
        httpSession.invalidate();
        return ResponseUtil.toSuccessResponseVo();
    }

    @RequestMapping(value = "/getUserById",method = RequestMethod.GET)
    @ApiOperation("通过userId查找用户")
    public ResponseVo<UserBasicInfo>getUserById(@RequestParam("userId") Long userId){
        UserBasicInfo user = userService.getUserByUserId(userId);
        return ResponseUtil.toSuccessResponseVo(user);
    }

    @RequestMapping(value = "/getUserByName",method = RequestMethod.GET)
    @ApiOperation("通过userName查找用户")
    public ResponseVo<UserBasicInfo>getUserByName(@RequestParam("userName") String userName){
        UserBasicInfo user = userService.getUserByUserName(userName);
        return ResponseUtil.toSuccessResponseVo(user);
    }

    @RequestMapping(value = "/deleteUser",method = RequestMethod.DELETE)
    @ApiOperation("删除用户")
    public ResponseVo<Object>deleteUser(@RequestParam("userId") Long userId, HttpServletRequest httpServletRequest){
        HttpSession httpSession = httpServletRequest.getSession();
        return userService.deleteUser(userId,httpSession);
    }

    @RequestMapping(value = "/updateUser",method = RequestMethod.PUT)
    @ApiOperation("修改用户")
    public ResponseVo<Object>updateUser(@RequestBody UserBasicInfo userBasicInfo, HttpServletRequest httpServletRequest){
        HttpSession httpSession = httpServletRequest.getSession();
        return userService.updateUser(userBasicInfo,httpSession);
    }

    @RequestMapping(value = "/getVerifyCode",method = RequestMethod.GET)
    @ApiOperation("得到验证码")
    public void getVerifyCode(HttpServletResponse httpServletResponse,HttpServletRequest httpServletRequest)throws Exception{
        HttpSession httpSession = httpServletRequest.getSession();
        Object[] objects = VerifyCodeUtil.createImage();
        httpSession.setAttribute("imageCode",objects[0]);
        BufferedImage bufferedImage = (BufferedImage) objects[1];
        httpServletResponse.setContentType("image/png");
        OutputStream outputStream = httpServletResponse.getOutputStream();
        ImageIO.write(bufferedImage,"png",outputStream);
    }

}
