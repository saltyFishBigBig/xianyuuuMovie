package org.saltfish.cinema.controller.ad;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.service.storage.CarouselService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URLDecoder;

@Api
@CrossOrigin
@RestController
@RequestMapping("/carouse")
public class CarouselController {
    private final CarouselService carouselService;

    @Autowired
    public CarouselController(CarouselService carouselService) {

        this.carouselService = carouselService;

    }

    @PostMapping("/getPath")
    @ApiOperation("获取当前所有轮播图片的地址")
    public ResponseVo<Object> getPath(){
        String fileUrl = "E:\\cinema\\src\\main\\resources\\static\\carousel";
        File files = new File(fileUrl);
        String list[];
        String [] fileList = new String[7];
        list = files.list();
        String url = "E:/cinema/src/main/resources/static/carousel/";
        int flag=0;
        if(list.length>7)
            flag = list.length-7;
        for (int i = list.length - 1, j = 0; i >= flag; i--) {
            fileList[j++] = url+list[i];
        }
        return ResponseUtil.toSuccessResponseVo(fileList);
    }

    // 以POST方式获得请求，图片上传成功后，以JSON格式将图片返回，用于回显 
    @PostMapping("/upload")
    @ApiOperation("上传轮播图片，返回所有图片地址用于回显")
    public ResponseVo<Object> handleFileUpload(@RequestParam("file") MultipartFile file) {
        String fileName = String.valueOf(System.currentTimeMillis())+file.getOriginalFilename();
        carouselService.storeCarousel(file,fileName);
        String fileUrl = "E:\\cinema\\src\\main\\resources\\static\\carousel";
        File files = new File(fileUrl);
        String list[];
        String [] fileList = new String[7];
        list = files.list();
        String url = "E:/cinema/src/main/resources/static/carousel/";
        int flag=0;
        if(list.length>7)
            flag = list.length-7;
        for (int i = list.length - 1, j = 0; i >= flag; i--) {
            fileList[j++] = url+list[i];
        }
        return ResponseUtil.toSuccessResponseVo(fileList);
    }

    @RequestMapping(value = "/getImg",produces = MediaType.IMAGE_JPEG_VALUE,method = RequestMethod.GET)
    @ResponseBody
    @ApiOperation("通过图片地址返回图片")
    public ResponseEntity<byte[]> getImg(@RequestParam("imgPath") String path) throws Exception {
        path= URLDecoder.decode(path,"utf-8");
        path = path.replaceAll("/","\\\\");
        byte[] imageContent ;
        imageContent = fileToByte(new File(path));
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<>(imageContent, headers, HttpStatus.OK);
    }

    public static byte[] fileToByte(File img) throws Exception {
        byte[] bytes = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            BufferedImage bi;
            bi = ImageIO.read(img);
            ImageIO.write(bi, "png", baos);
            bytes = baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            baos.close();
        }
        return bytes;
    }
}
