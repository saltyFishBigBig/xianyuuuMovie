package org.saltfish.cinema.commons.response;

public class ExceptionMessages {
    public static final String SUCCESS = "操作成功";
    /*user*/
    public static final String USER_NAME_IS_TOO_LONG = "用户名不要超过二十个字符";
    public static final String DOUBLE_USER_NAME = "用户名已经被注册了";
    public static final String PASSWORD_IS_TOO_LONG = "密码不要超过二十个字符";
    public static final String PASSWORD_IS_TOO_SHORT = "密码不要少于六个字符";
    public static final String EMAIL_FORMAT_WRONG = "邮箱格式有误";
    public static final String USERNAME_NOT_EXIST = "用户不存在";
    public static final String PASSWORD_WRONG = "密码错误";
    public static final String PHONENUMBER_WRONG = "电话号码格式有误";
    public static final String PARAMETER_CANNOT_NULL = "信息没有填写完整";
    public static final String VERIFYCODE_NULL = "验证码不能为空";
    public static final String VERIFYCODE_FAIL = "验证码验证失败";
    public static final String NOT_MANAGER = "没有管理员权限";
    public static final String ACCOUNT_NOT_ENOUGH = "用户余额不足";
}
