package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.CinemaBasicInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;


public interface CinemaRepository extends JpaRepository<CinemaBasicInfo, Long>, JpaSpecificationExecutor {

    /**
     * 通过地区筛选影院
     * @param area
     * @return
     */
    List<CinemaBasicInfo> findByArea(String area);


    /**
     * 获取一个影院
     * @param cinemaId
     * @return
     */
    CinemaBasicInfo findByCinemaId(Long cinemaId);


    /**
     * 根据影院名称模糊查询
     * @param name
     * @return
     */
    List<CinemaBasicInfo> findByCinemaNameLike(String name);
}
