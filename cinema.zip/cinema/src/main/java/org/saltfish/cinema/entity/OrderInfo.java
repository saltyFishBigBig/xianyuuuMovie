package org.saltfish.cinema.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.saltfish.cinema.commons.annotation.Comment;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Table
@Entity
@NoArgsConstructor
public class OrderInfo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    @Comment(comment = "订单编号")
    private String orderNumber;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn
    @Comment(comment = "哪个用户")
    private UserBasicInfo userBasicInfo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn
    @Comment(comment = "哪场电影")
    private CinemaMovieInfo cinemaMovieInfo;

    @Comment(comment = "座次-第几行")
    private Integer row;


    @Comment(comment = "座次-第几列")
    private Integer line;

    @Comment(comment = "是否为情侣座")
    private Boolean loverSeat;

    @Comment(comment = "是否已经付款")
    @Enumerated(EnumType.STRING)
    private OrderStatusEnum orderStatus;
}
