package org.saltfish.cinema.service.user.impl;

import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.dao.UserRepository;
import org.saltfish.cinema.entity.UserBasicInfo;
import org.saltfish.cinema.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.Objects;

import static org.saltfish.cinema.commons.response.ExceptionMessages.*;
import static org.saltfish.cinema.commons.response.ResponseStatus.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    @Override
    public void addUserByPhoneNumber(UserBasicInfo userBasicInfo) {
        checkPhoneNumber(userBasicInfo.getPhoneNumber());
        checkAddUserParameter(userBasicInfo);
        userRepository.save(userBasicInfo);
    }

    @Override
    public void addUserByEmail(UserBasicInfo userBasicInfo) {
        checkEmail(userBasicInfo.getEmail());
        checkAddUserParameter(userBasicInfo);
        userRepository.save(userBasicInfo);
    }

    @Override
    public UserBasicInfo checkUser(UserBasicInfo userBasicInfo) {
        UserBasicInfo getUser = userRepository.findByUserName(userBasicInfo.getUserName());
        UserBasicInfo user = null;
        if(getUser == null || !userBasicInfo.getPassword().equals(getUser.getPassword())){
            return user;
        }
        return getUser;
    }

    @Override
    public ResponseVo<Object> deleteUser(Long userId,HttpSession httpSession) {
        Long id = (Long) httpSession.getAttribute("userId");
        if(userId != id){
            UserBasicInfo userBasicInfo = getUserByUserId(id);
            if(!userBasicInfo.isManager()){
                return ResponseUtil.toFailResponseVo(FORBIDDEN,NOT_MANAGER);
            }
        }
        return ResponseUtil.toSuccessResponseVo();
    }

    @Override
    public ResponseVo<Object> updateUser(UserBasicInfo userBasicInfo, HttpSession httpSession) {
        Long id = (Long) httpSession.getAttribute("userId");
        Long userId = userBasicInfo.getUserId();
        if(userId != id){
            UserBasicInfo user= getUserByUserId(id);
            if(!user.isManager()){
                return ResponseUtil.toFailResponseVo(FORBIDDEN,NOT_MANAGER);
            }
        }
        userRepository.save(userBasicInfo);
        return ResponseUtil.toSuccessResponseVo();
    }

    @Override
    public UserBasicInfo getUserByUserId(Long userId) {
        UserBasicInfo userBasicInfo = userRepository.findByUserId(userId);
        return userBasicInfo;
    }

    @Override
    public UserBasicInfo getUserByUserName(String userName) {
        UserBasicInfo userBasicInfo = userRepository.findByUserName(userName);
        return userBasicInfo;
    }

    private void checkAddUserParameter(UserBasicInfo userBasicInfo){
        if(userBasicInfo.getUserName() == null || userBasicInfo.getPassword() == null){
        }
        ResponseUtil.toFailResponseVo(BAD_REQUEST,PARAMETER_CANNOT_NULL);
        checkUserName(userBasicInfo.getUserName());
        checkPassword(userBasicInfo.getPassword());
    }

    private void checkUserName(String userName){
        UserBasicInfo userBasicInfo = userRepository.findByUserName(userName);
        if(userBasicInfo != null){
            ResponseUtil.toFailResponseVo(BAD_REQUEST,DOUBLE_USER_NAME);
        }
        else if(userName.length()>20){
            ResponseUtil.toFailResponseVo(BAD_REQUEST,USER_NAME_IS_TOO_LONG);
        }
    }

    private void checkPassword(String password){
        if(password.length()>20)
            ResponseUtil.toFailResponseVo(BAD_REQUEST,PASSWORD_IS_TOO_LONG);
        if(password.length()<6)
            ResponseUtil.toFailResponseVo(BAD_REQUEST,PASSWORD_IS_TOO_SHORT);
    }

    private void checkEmail(String email){
        if(!isEmail(email))
            ResponseUtil.toFailResponseVo(BAD_REQUEST,EMAIL_FORMAT_WRONG);
    }

    private void checkPhoneNumber(String phoneNumber){
        if(!isPhoneNumber(phoneNumber))
            ResponseUtil.toFailResponseVo(BAD_REQUEST,PHONENUMBER_WRONG);
    }

    private static boolean isEmail(String email){
        String regExp="^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$";
        return email.matches(regExp);
    }

    private static boolean isPhoneNumber(String phoneNumber){
        String regExp="^1([38]\\d|5[0-35-9]|7[3678])\\d{8}$";
        return phoneNumber.matches(regExp);
    }
}
