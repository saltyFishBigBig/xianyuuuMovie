package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.UserBasicInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface UserRepository extends JpaRepository<UserBasicInfo,Long>, JpaSpecificationExecutor {

    UserBasicInfo findByUserName(String userName);

    UserBasicInfo findByUserId(Long userId);
}
