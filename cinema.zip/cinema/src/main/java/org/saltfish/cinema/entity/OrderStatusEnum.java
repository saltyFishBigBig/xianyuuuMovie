package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;

@ApiModel("订单状态视图")
public enum OrderStatusEnum {

    //
    TOPAY("等待付款"),
    PAYED("已付款"),
    UNDO("已退票");

    private String comment;

    OrderStatusEnum(String comment) {
        this.comment = comment;
    }
}
