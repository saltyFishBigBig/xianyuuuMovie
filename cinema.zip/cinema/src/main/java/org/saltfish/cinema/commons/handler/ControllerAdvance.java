package org.saltfish.cinema.commons.handler;

import org.saltfish.cinema.commons.response.ResponseStatus;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ControllerAdvance {

    @ResponseBody
    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseVo<Object> emptyResultDataAccessExceptionHandler(EmptyResultDataAccessException exception) {

        exception.printStackTrace();

        return ResponseUtil.toFailResponseVo(ResponseStatus.INTERNAL_SERVER_ERROR, "数据删除异常 ：" + exception.getMessage());
    }

    @ResponseBody
    @ExceptionHandler(Exception.class)
    public ResponseVo<Object> exceptionHandler(Exception exception){

        exception.printStackTrace();

        return ResponseUtil.toFailResponseVo(ResponseStatus.INTERNAL_SERVER_ERROR, "未知异常[" + exception.getMessage() + "]！请联系管理员");
    }
}
