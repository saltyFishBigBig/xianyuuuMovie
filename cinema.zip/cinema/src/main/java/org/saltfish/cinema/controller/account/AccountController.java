package org.saltfish.cinema.controller.account;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.AccountInfo;
import org.saltfish.cinema.service.account.AccountService;
import org.saltfish.cinema.service.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Api
@CrossOrigin
@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    AccountService accountService;

    @Autowired
    OrderService orderService;

    @PostMapping("/add")
    @ApiOperation("账户余额充值,参数为包含本次充值金额和userId的对象")
    public ResponseVo<Object> addAccount(@RequestBody AccountInfo accountInfo){
        double account = accountInfo.getAccount();
        Long userId = accountInfo.getUserId();
        if(accountService.findByUserId(userId) == null){
            accountService.saveAccount(accountInfo);
            return ResponseUtil.toSuccessResponseVo();
        } else {
            AccountInfo getAccount = accountService.findByUserId(userId);
            double getAccounts = getAccount.getAccount();
            double accounts = account + getAccounts;
            getAccount.setAccount(accounts);
            accountService.saveAccount(getAccount);
        }
        return ResponseUtil.toSuccessResponseVo();
    }

    @PostMapping("/reduce")
    @ApiOperation("用户完成订单，余额扣除")
    public ResponseVo<Object> reduceAccount(@RequestParam("orderId") Long orderId){
        return accountService.decreaseAccount(orderId);
    }

    @PostMapping("/return")
    @ApiOperation("用户退掉订单，返还余额")
    public ResponseVo<Object> returnAccount(@RequestParam("orderId") Long orderId){
        return accountService.plusAccount(orderId);
    }
}
