package org.saltfish.cinema.service.order.impl;

import org.saltfish.cinema.commons.util.NumberFormatUtil;
import org.saltfish.cinema.dao.CinemaMovieRepository;
import org.saltfish.cinema.dao.OrderReposiroty;
import org.saltfish.cinema.dao.UserRepository;
import org.saltfish.cinema.entity.OrderInfo;
import org.saltfish.cinema.entity.OrderStatusEnum;
import org.saltfish.cinema.entity.dto.OrderDto;
import org.saltfish.cinema.service.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderReposiroty orderReposiroty;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private CinemaMovieRepository cinemaMovieRepository;

    @Override
    public List<OrderInfo> addOrder(OrderDto orderDto) {

        OrderInfo orderInfo = new OrderInfo();

        orderInfo.setUserBasicInfo(userRepository.getOne(orderDto.getUserBasicInfoId()));
        orderInfo.setCinemaMovieInfo(cinemaMovieRepository.getOne(orderDto.getCinemaMovieInfoId()));
        orderInfo.setLine(orderDto.getLine());
        orderInfo.setRow(orderDto.getRow());
        orderInfo.setLoverSeat(orderDto.getLoverSeat());
        orderInfo.setOrderStatus(OrderStatusEnum.TOPAY);

        System.out.println(orderInfo);

        // 处理订单编号
        OrderInfo order = orderReposiroty.saveAndFlush(orderInfo);
        order.setOrderNumber(NumberFormatUtil.numberFormat(order.getOrderId()));
        orderReposiroty.save(order);

        return null;
    }

    @Override
    public List<OrderInfo> undoOrder(Long orderId) {

        OrderInfo orderInfo = orderReposiroty.getOne(orderId);

        orderInfo.setOrderStatus(OrderStatusEnum.UNDO);

        orderReposiroty.save(orderInfo);

        return null;
    }

    @Override
    public List<OrderInfo> getAllOrders(Long userId) {
        return orderReposiroty.findByUserBasicInfo_UserId(userId);
    }

    @Override
    public List<OrderInfo> getOrderOfStatus(Long userId, OrderStatusEnum orderStatus) {
        return orderReposiroty.findByUserBasicInfo_UserIdAndOrderStatus(userId, orderStatus);
    }

    @Override
    public OrderInfo getOrderByOrderId(Long orderId) {
        return orderReposiroty.getOne(orderId);
    }

    @Override
    public List<OrderInfo> getOrdersOfCinemaMovie(Long cinemaMovieId) {
        return orderReposiroty.findByCinemaMovieInfo_CinemaMovieId(cinemaMovieId);
    }
}
