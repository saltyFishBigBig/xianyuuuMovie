package org.saltfish.cinema.controller.upload;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.net.URLDecoder;
import java.util.stream.Collectors;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.service.storage.StorageService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.core.io.Resource;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;


@Api
@CrossOrigin
@RestController
@RequestMapping("/file")
public class FileUploadController {

    private final StorageService storageService;

    @Autowired
    public FileUploadController(StorageService storageService) {

        this.storageService = storageService;

    }

    // 以POST方式获得请求，图片上传成功后，以JSON格式将图片返回，用于回显 
    @PostMapping("/upload")
    @ApiOperation("上传图片，返回json格式的图片用于回显")
    public ResponseVo<Object> handleFileUpload(@RequestParam("file") MultipartFile file) {
        String imgUrl = "E:/cinema/src/main/resources/static/upload-dir/" + file.getOriginalFilename();
        storageService.store(file);
        return ResponseUtil.toSuccessResponseVo(imgUrl);
    }

    @RequestMapping(value = "/getImg",produces = MediaType.IMAGE_JPEG_VALUE,method = RequestMethod.GET)
    @ResponseBody
    @ApiOperation("通过图片地址返回图片")
    public ResponseEntity<byte[]> getImg(@RequestParam("imgPath") String path) throws Exception {
        path=URLDecoder.decode(path,"utf-8");
        path = path.replaceAll("/","\\\\");
        byte[] imageContent ;
        imageContent = fileToByte(new File(path));
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<>(imageContent, headers, HttpStatus.OK);
    }

    public static byte[] fileToByte(File img) throws Exception {
        byte[] bytes = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            BufferedImage bi;
            bi = ImageIO.read(img);
            ImageIO.write(bi, "png", baos);
            bytes = baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            baos.close();
        }
        return bytes;
    }
}
