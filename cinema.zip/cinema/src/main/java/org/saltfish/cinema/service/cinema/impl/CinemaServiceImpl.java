package org.saltfish.cinema.service.cinema.impl;

import org.saltfish.cinema.dao.CinemaRepository;
import org.saltfish.cinema.entity.CinemaBasicInfo;
import org.saltfish.cinema.service.cinema.CinemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CinemaServiceImpl implements CinemaService {

    @Autowired
    private CinemaRepository cinemaRepository;

    @Override
    public void saveCinema(CinemaBasicInfo cinemaBasicInfo) {
        cinemaRepository.save(cinemaBasicInfo);
    }

    @Override
    public void deleteCinema(Long cinemaId) {
        cinemaRepository.deleteById(cinemaId);
    }

    @Override
    public List<CinemaBasicInfo> findByArea(String area) {
        return cinemaRepository.findByArea(area);
    }

    @Override
    public CinemaBasicInfo getCinema(Long cinemaId) {
        return cinemaRepository.findByCinemaId(cinemaId);
    }

    @Override
    public List<CinemaBasicInfo> findAllCinemas() {
        return cinemaRepository.findAll();
    }

    @Override
    public List<CinemaBasicInfo> findByNameLick(String name) {
        return cinemaRepository.findByCinemaNameLike(name);
    }
}
