package org.saltfish.cinema.commons.util;

public abstract class NumberFormatUtil {
    
    /**
     * 解决订单的的编号问题
     **/
    public static String numberFormat(Long id) {
        String str = id.toString();
        String number;
        if (str.length() > 8) {
            number = str.substring(str.length());
        } else {
            number = String.format( "1011" + "%04d", id);
        }
        return number;
    }
}
