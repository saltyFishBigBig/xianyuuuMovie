package org.saltfish.cinema.controller.order;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.OrderInfo;
import org.saltfish.cinema.entity.OrderStatusEnum;
import org.saltfish.cinema.entity.dto.OrderDto;
import org.saltfish.cinema.service.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Api
@CrossOrigin
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    @ApiOperation("下订单")
    public ResponseVo<List<OrderInfo>> addOrder(@RequestBody OrderDto orderDto) {
        return ResponseUtil.toSuccessResponseVo(orderService.addOrder(orderDto));
    }

    @PutMapping
    @ApiOperation("退票")
    public ResponseVo<List<OrderInfo>> undoOrder(@RequestParam Long orderId) {
        return ResponseUtil.toSuccessResponseVo(orderService.undoOrder(orderId));
    }

    @GetMapping("/all")
    @ApiOperation("查看某一用户的全部订单详情")
    public ResponseVo<List<OrderInfo>> getAllOrders(@RequestParam Long userId) {
        return ResponseUtil.toSuccessResponseVo(orderService.getAllOrders(userId));
    }

    @GetMapping("/topay")
    @ApiOperation("查看某一用户未付款的订单")
    public ResponseVo<List<OrderInfo>> getToPayOrders(@RequestParam Long userId) {
        return ResponseUtil.toSuccessResponseVo(orderService.getOrderOfStatus(userId, OrderStatusEnum.TOPAY));
    }

    @GetMapping("/payed")
    @ApiOperation("查看某一用户已付款的订单")
    public ResponseVo<List<OrderInfo>> getPayedOrders(@RequestParam Long userId) {
        return ResponseUtil.toSuccessResponseVo(orderService.getOrderOfStatus(userId, OrderStatusEnum.PAYED));
    }

    @GetMapping("/undo")
    @ApiOperation("查看某一用户已退票的订单")
    public ResponseVo<List<OrderInfo>> getUndoOrders(@RequestParam Long userId) {
        return ResponseUtil.toSuccessResponseVo(orderService.getOrderOfStatus(userId, OrderStatusEnum.UNDO));
    }

    @GetMapping("/movie")
    @ApiOperation("获取某场电影的全部订单")
    public ResponseVo<List<OrderInfo>> getOrdersOfCinemaMovie(@RequestParam Long cinemaMovieId) {
        return ResponseUtil.toSuccessResponseVo(orderService.getOrdersOfCinemaMovie(cinemaMovieId));
    }

}
