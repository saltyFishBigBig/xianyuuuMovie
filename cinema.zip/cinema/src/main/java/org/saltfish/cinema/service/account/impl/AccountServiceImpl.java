package org.saltfish.cinema.service.account.impl;

import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.dao.AccountRepository;
import org.saltfish.cinema.dao.OrderReposiroty;
import org.saltfish.cinema.entity.AccountInfo;
import org.saltfish.cinema.entity.OrderInfo;
import org.saltfish.cinema.entity.OrderStatusEnum;
import org.saltfish.cinema.entity.UserBasicInfo;
import org.saltfish.cinema.service.account.AccountService;
import org.saltfish.cinema.service.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static org.saltfish.cinema.commons.response.ExceptionMessages.ACCOUNT_NOT_ENOUGH;
import static org.saltfish.cinema.commons.response.ResponseStatus.FORBIDDEN;

@Service
public class AccountServiceImpl implements AccountService{

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private OrderReposiroty orderReposiroty;

    @Autowired
    OrderService orderService;

    @Override
    public void saveAccount(AccountInfo accountInfo) {
        accountRepository.save(accountInfo);
    }

    @Override
    public void deleteAccount(Long accountId) {
        accountRepository.deleteById(accountId);
    }

    @Override
    public AccountInfo findByUserId(Long userId) {
        return accountRepository.findAccountByUserId(userId);
    }

    @Override
    public ResponseVo<Object> decreaseAccount(Long orderId) {
        OrderInfo orderInfo = orderService.getOrderByOrderId(orderId);
        UserBasicInfo userBasicInfo = orderInfo.getUserBasicInfo();
        Long userId = userBasicInfo.getUserId();
        double price = orderInfo.getCinemaMovieInfo().getPrice();
        AccountInfo accountInfo = findByUserId(userId);
        double account = accountInfo.getAccount();
        if(price > account){
            return ResponseUtil.toFailResponseVo(FORBIDDEN,ACCOUNT_NOT_ENOUGH);
        }
        account-=price;
        accountInfo.setAccount(account);
        saveAccount(accountInfo);

        orderInfo.setOrderStatus(OrderStatusEnum.PAYED);
        orderReposiroty.save(orderInfo);

        return ResponseUtil.toSuccessResponseVo();
    }

    @Override
    public ResponseVo<Object> plusAccount(Long orderId) {
        OrderInfo orderInfo = orderService.getOrderByOrderId(orderId);
        UserBasicInfo userBasicInfo = orderInfo.getUserBasicInfo();
        Long userId = userBasicInfo.getUserId();
        double price = orderInfo.getCinemaMovieInfo().getPrice();
        AccountInfo accountInfo = findByUserId(userId);
        double account = accountInfo.getAccount();
        account += price;
        accountInfo.setAccount(account);
        saveAccount(accountInfo);

        return ResponseUtil.toSuccessResponseVo();
    }
}
