package org.saltfish.cinema.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import org.saltfish.cinema.commons.annotation.Comment;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table
@ApiModel("用户视图")
public class UserBasicInfo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    private String userName;

    private String password;

    private String phoneNumber;

    private String email;

    @ApiModelProperty("用户头像存放路径")
    private String avatar;

    @ApiModelProperty("是否为管理员")
    private boolean manager;
}
