package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.AccountInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AccountRepository extends JpaRepository<AccountInfo,Long>,JpaSpecificationExecutor{
    AccountInfo findAccountByUserId(Long userId);
}
