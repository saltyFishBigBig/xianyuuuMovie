package org.saltfish.cinema.commons.response;

public enum ResponseStatus {


    
    // 200：客户端请求成功被服务端受理且办理成功，将返回该请求需要的数据
    OK(200,"OK"),
    
    // 204：客户端请求成功被服务端受理且办理成功，但是并不需要返回给客户端数据
    NO_CONTENT(204,"No Content"),
    
    // 400：客户端请求参数缺失、参数格式不正确、参数解析错误、参数校验不通过时
    BAD_REQUEST(400,"Bad Request"),

    // 401：需要进行认证的时候却没有进行认证，例如修改密码、登录等
    UNAUTHORIZED(401,"Unauthorized"),

    // 403：禁止某些操作
    FORBIDDEN(403,"Forbidden"),

    // 404：业务受理且办理成功，但是服务器上面不存在这个资源
    NOT_FOUND(404,"Not Found"),

    // 500：服务端内部的未知错误，如果出现未检查的服务端运行时异常
    INTERNAL_SERVER_ERROR(500,"Internal Server Error"),

    // 503：服务不可以，用于拥塞控制响应和停机维护
    SERVICE_UNAVAILABLE(503,"Service Unavailable");

    private int code;

    private String comment;

    ResponseStatus(int code, String comment) {
        this.code = code;
        this.comment = comment;
    }
}
