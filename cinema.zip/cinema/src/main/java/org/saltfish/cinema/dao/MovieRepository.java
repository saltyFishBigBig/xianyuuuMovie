package org.saltfish.cinema.dao;

import org.saltfish.cinema.entity.MovieBasicInfo;
import org.saltfish.cinema.entity.MovieLevelEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface MovieRepository extends JpaRepository<MovieBasicInfo, Long>, JpaSpecificationExecutor {

    MovieBasicInfo findByMovieId(Long movieId);

    List<MovieBasicInfo> findByLevel(MovieLevelEnum level);


    List<MovieBasicInfo> findByMovieNameLike(String name);
}
