package org.saltfish.cinema.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Table
@Entity
@ApiModel("电影院与电影关系视图")
public class CinemaMovieInfo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cinemaMovieId;

    @ManyToOne(fetch = FetchType.EAGER,optional = false)
    @JoinColumn(nullable = false,updatable = false)
    @ApiModelProperty("哪个影院")
    private CinemaBasicInfo cinemaBasicInfo;

    @ManyToOne(fetch = FetchType.EAGER,optional = false)
    @JoinColumn(nullable = false,updatable = false)
    @ApiModelProperty("哪部电影")
    private MovieBasicInfo movieBasicInfo;

    @ApiModelProperty("开始放映时间（仅时分）")
    private String beginTime;

    @ApiModelProperty("散场时间（仅时分）")
    private String endTime;

    @ApiModelProperty("语言版本")
    private String version;

    @ApiModelProperty("放映厅")
    private String hall;

    @ApiModelProperty("售价")
    private Double price;
}
