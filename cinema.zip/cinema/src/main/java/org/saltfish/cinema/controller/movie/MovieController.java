package org.saltfish.cinema.controller.movie;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.saltfish.cinema.commons.response.ResponseStatus;
import org.saltfish.cinema.commons.response.ResponseUtil;
import org.saltfish.cinema.commons.response.ResponseVo;
import org.saltfish.cinema.entity.CinemaBasicInfo;
import org.saltfish.cinema.entity.CinemaMovieInfo;
import org.saltfish.cinema.entity.MovieBasicInfo;
import org.saltfish.cinema.entity.MovieLevelEnum;
import org.saltfish.cinema.service.movie.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api
@CrossOrigin
@RestController
@RequestMapping("/movie")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @PostMapping
    @ApiOperation("添加影片，不需要影片id")
    public ResponseVo<Object> addMovie(@RequestBody MovieBasicInfo movieBasicInfo) {

        movieService.saveMovie(movieBasicInfo);

        return ResponseUtil.toSuccessResponseVo();
    }

    @PutMapping
    @ApiOperation("修改影片信息，需要影片id")
    public ResponseVo<Object> updateMovie(@RequestBody MovieBasicInfo movieBasicInfo) {

        movieService.saveMovie(movieBasicInfo);

        return ResponseUtil.toSuccessResponseVo();
    }

    @PostMapping("/cinema")
    @ApiOperation("添加影院中影片，不需要影片id")
    public ResponseVo<Object> addCinemaMovie(@RequestBody CinemaMovieInfo cinemaMovieInfo) {

        movieService.saveCinemaMovie(cinemaMovieInfo);

        return ResponseUtil.toSuccessResponseVo();
    }

    @PutMapping("/cinema")
    @ApiOperation("修改影院中影片信息，需要影片id")
    public ResponseVo<Object> updateCinemaMovie(@RequestBody CinemaMovieInfo cinemaMovieInfo) {

        movieService.saveCinemaMovie(cinemaMovieInfo);

        return ResponseUtil.toSuccessResponseVo();
    }

    @DeleteMapping
    @ApiOperation("删除影片")
    public ResponseVo<Object> deleteMovie(@RequestParam Long movieId) {

        movieService.deleteMovie(movieId);

        return ResponseUtil.toSuccessResponseVo();
    }

    @DeleteMapping("/cinema")
    @ApiOperation("删除影院中影片")
    public ResponseVo<Object> deleteCinemaMovie(@RequestParam Long cinemaMovieId) {

        movieService.deleteCinemaMovie(cinemaMovieId);

        return ResponseUtil.toSuccessResponseVo();
    }

    @GetMapping
    @ApiOperation("通过影片id查询影片自身信息")
    public ResponseVo<MovieBasicInfo> findMovieById(@RequestParam Long movieId) {

        MovieBasicInfo movieBasicInfo = movieService.findMovieById(movieId);

        if(movieBasicInfo == null) {
            return ResponseUtil.toFailResponseVo(ResponseStatus.NOT_FOUND, "该影片不存在");
        }

        return ResponseUtil.toSuccessResponseVo(movieBasicInfo);
    }

    @GetMapping("/all")
    @ApiOperation("获取全部影片")
    public ResponseVo<List<MovieBasicInfo>> getAllMovies() {

        return ResponseUtil.toSuccessResponseVo(movieService.getAllMovies());

    }

    @GetMapping("/hot")
    @ApiOperation("获取正在热映的影片")
    public ResponseVo<List<MovieBasicInfo>> findByHotMovie() {

        return ResponseUtil.toSuccessResponseVo(movieService.findByMovieLevel(MovieLevelEnum.HOT));
    }

    @GetMapping("/ready")
    @ApiOperation("获取即将上映的影片")
    public ResponseVo<List<MovieBasicInfo>> findByReadyMovie() {

        return ResponseUtil.toSuccessResponseVo(movieService.findByMovieLevel(MovieLevelEnum.READY));
    }

    @GetMapping("/other")
    @ApiOperation("获取普通上映的影片")
    public ResponseVo<List<MovieBasicInfo>> findOtherMovie() {

        return ResponseUtil.toSuccessResponseVo(movieService.findByMovieLevel(MovieLevelEnum.OTHER));
    }

    @GetMapping("/cinema/all")
    @ApiOperation("通过影片id查询所有上映了该影片的影院及影院中该影片的上映情况")
    public ResponseVo<List<CinemaMovieInfo>> findCinemaMoviesByMovieId(@RequestParam Long movieId) {

        return ResponseUtil.toSuccessResponseVo(movieService.findCinemaMoviesByMovieId(movieId));
    }

    @GetMapping("/cinema")
    @ApiOperation("通过影院中上映的影片id查询该影片的上映情况")
    public ResponseVo<CinemaMovieInfo> findCinemaMovieById(@RequestParam Long cinemaMovieId) {

        return ResponseUtil.toSuccessResponseVo(movieService.findCinemaMovieById(cinemaMovieId));
    }

    @GetMapping("/cinema/all/movie")
    @ApiOperation("获取某一影院中的全部影片信息")
    public ResponseVo<List<CinemaMovieInfo>> findMoviesByCinema(@RequestParam Long cinemaId) {

        return ResponseUtil.toSuccessResponseVo(movieService.findMoviesByCinema(cinemaId));
    }


    @GetMapping("/like/name")
    @ApiOperation("根据影院名称的模糊查询")
    public ResponseVo<List<MovieBasicInfo>> findByNameLike(@RequestParam String name) {
        return ResponseUtil.toSuccessResponseVo(movieService.findByNameLick("%"+name+"%"));
    }


}
