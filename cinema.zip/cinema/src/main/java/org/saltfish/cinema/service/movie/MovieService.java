package org.saltfish.cinema.service.movie;

import org.saltfish.cinema.entity.CinemaBasicInfo;
import org.saltfish.cinema.entity.CinemaMovieInfo;
import org.saltfish.cinema.entity.MovieBasicInfo;
import org.saltfish.cinema.entity.MovieLevelEnum;

import java.util.List;

public interface MovieService {

    /**
     * 增加或修改影片信息
     * @param movieBasicInfo
     */
    void saveMovie(MovieBasicInfo movieBasicInfo);

    /**
     * 增加或修改场次信息
     * @param cinemaMovieInfo
     */
    void saveCinemaMovie(CinemaMovieInfo cinemaMovieInfo);

    /**
     * 删除影片信息
     * @param movieId
     */
    void deleteMovie(Long movieId);

    /**
     * 删除场次信息
     * @param cinemaMovieId
     */
    void deleteCinemaMovie(Long cinemaMovieId);

    /**
     * 通过影片id查询影片自身信息
     * @param movieId
     * @return
     */
    MovieBasicInfo findMovieById(Long movieId);

    /**
     * 获取全部影片
     * @return
     */
    List<MovieBasicInfo> getAllMovies();

    /**
     * 根据影片上映程度（正在上映/普通上映/热映这种）获取影片
     * @param movieLevel
     * @return
     */
    List<MovieBasicInfo> findByMovieLevel(MovieLevelEnum movieLevel);

    /**
     * 通过影片id查询所有上映了该影片的影院及影院中该影片的上映情况
     * @param movieId
     * @return
     */
    List<CinemaMovieInfo> findCinemaMoviesByMovieId(Long movieId);

    /**
     * 通过影院中上映的影片id查询该影片的上映情况
     * @param cinemaMovieId
     * @return
     */
    CinemaMovieInfo findCinemaMovieById(Long cinemaMovieId);

    /**
     * 获取某一影院中的全部影片信息
     * @param cinemaId
     * @return
     */
    List<CinemaMovieInfo> findMoviesByCinema(Long cinemaId);



    List<MovieBasicInfo> findByNameLick(String name);


}
